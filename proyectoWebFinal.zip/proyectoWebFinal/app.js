require('dotenv').config();
const authRoutes = require('./src/routes/auth-routes');
const recipeRoutes = require('./src/routes/recipe-routes');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public'))); // Servir tus HTML/CSS/JS

// Conexión a Base de Datos Mongoose
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('✅ Conectado a MongoDB (recetastico_db)'))
    .catch(err => console.error('❌ Error conectando a MongoDB:', err));

    //Rutas
app.use('/api/auth', authRoutes);
app.use('/api/recetas', recipeRoutes);

// Ruta base para el frontend
app.get('/', (req, res) => {
    res.redirect('/Vistavisitante/home.html');
});

app.listen(PORT, () => {
    console.log(` servidor corriendo en http://localhost:${PORT}`);
});