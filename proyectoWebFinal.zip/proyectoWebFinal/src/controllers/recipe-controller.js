const Recipe = require('../models/Recipe');

// CREAR RECETA 
exports.createRecipe = async (req, res) => {
    try {
        const nuevaReceta = new Recipe({
            ...req.body,
            autor: req.user.id // ID viene del middleware de auth
        });
        const receta = await nuevaReceta.save();
        res.status(201).json(receta);
    } catch (error) {
        res.status(500).json({ msg: 'Error al crear la receta' });
    }
};

// OBTENER RECETAS (pub con paginacion y filtros)
exports.getRecipes = async (req, res) => {
    try {
        const { page = 1, limit = 10, categoria, titulo } = req.query;

        // Construir filtro dinámico
        let query = {};
        if (categoria) query.categoria = categoria;
        if (titulo) query.titulo = { $regex: titulo, $options: 'i' }; // Búsqueda parcial insensible a mayúsculas

        // Ejecutar consulta con paginación
        const recetas = await Recipe.find(query)
            .limit(limit * 1)
            .skip((page - 1) * limit)
            .populate('autor', 'nombre') // Traer solo el nombre del autor
            .exec();

        const count = await Recipe.countDocuments(query);

        res.json({
            recetas,
            totalPages: Math.ceil(count / limit),
            currentPage: page
        });
    } catch (error) {
        res.status(500).json({ msg: 'Error al obtener recetas' });
    }
};

// Obtener receta por ID
exports.getRecipeById = async (req, res) => {
    try {
        const receta = await Recipe.findById(req.params.id).populate('autor', 'nombre');
        if (!receta) return res.status(404).json({ msg: 'Receta no encontrada' });
        res.json(receta);
    } catch (error) {
        res.status(500).json({ msg: 'Error del servidor' });
    }
};

// Eliminar receta(solo para el autor o un admin)
exports.deleteRecipe = async (req, res) => {
    try {
        const receta = await Recipe.findById(req.params.id);
        if (!receta) return res.status(404).json({ msg: 'Receta no encontrada' });

        // Verificar si el usuario es el dueño
        if (receta.autor.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(401).json({ msg: 'No autorizado para eliminar esta receta' });
        }

        await receta.deleteOne();
        res.json({ msg: 'Receta eliminada' });
    } catch (error) {
        res.status(500).json({ msg: 'Error al eliminar' });
    }
};