const express = require('express');
const router = express.Router();
const recipeController = require('../controllers/recipe-controller');
const auth = require('../middlewares/auth-middleware');

// Rutas Públicas
router.get('/', recipeController.getRecipes);
router.get('/:id', recipeController.getRecipeById);

// Rutas Privadas (Requieren Token)
router.post('/', auth, recipeController.createRecipe);
router.delete('/:id', auth, recipeController.deleteRecipe);

module.exports = router;