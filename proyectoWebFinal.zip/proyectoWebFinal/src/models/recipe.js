const mongoose = require('mongoose');

const recipeSchema = new mongoose.Schema({
    titulo: { type: String, required: true },
    descripcion: { type: String, required: true },
    ingredientes: [{
        nombre: String,
        cantidad: Number,
        unidad: String
    }],
    pasos: [String], // Array de instrucciones
    tiempoPrep: { type: Number, required: true }, // En minutos
    tiempoCoccion: { type: Number, required: true }, // En minutos
    categoria: { 
        type: String, 
        enum: ['desayuno', 'comida', 'cena', 'postre', 'entrada', 'mexicana', 'pasta', 'vegetariana'],
        required: true 
    },
    imageUrl: { type: String }, // URL de la imagen
    autor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Relación con el modelo de Usuario
        required: true
    },
    calificaciones: [{
        usuario: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        puntuacion: { type: Number, min: 1, max: 5 }
    }],
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Recipe', recipeSchema);